import xbmc,xbmcaddon,xbmcvfs,xbmcgui
import os
import xbmc, xbmcgui, xbmcplugin, xbmcvfs, xbmcaddon
import time


def log(x):
    xbmc.log(repr(x),xbmc.LOGERROR)



dialog = xbmcgui.Dialog().select('KODI CONFIG SETTINGS', ['Power Menu','Open Kodi Settings','Open File Manager','CoreELEC settings & WiFi Settings','Authorise Trakt','Authorise Real Debrid and Premiumize'])
if dialog==0:
	xbmc.executebuiltin('ActivateWindow(shutdownmenu)')

elif dialog==1:
	xbmc.executebuiltin('ActivateWindow(Settings)')

elif dialog==2:
	xbmc.executebuiltin('ActivateWindow(filemanager)')

elif dialog==3:
	xbmcgui.Dialog().ok('CoreELEC SETTINGS', 'Scroll to Connections and select your WiFi. Addon will open once you click OK')
	xbmc.executebuiltin('RunAddon(service.coreelec.settings)')

elif dialog==4:
	dialog = xbmcgui.Dialog().select('AUTHORISE TRAKT', ['Auth TRAKT Ezra then use Sync below','Sync TRAKT in Ezra','Auth TRAKT Seren','Auth TRAKT Umbrella','Auth TRAKT Shadow','Auth TRAKT Magic Dragon'])
	if dialog==0:
		xbmc.executebuiltin('RunScript(script.module.myaccounts, action=traktAuth)')
	elif dialog==1:
		xbmc.executebuiltin('RunScript(special://home/addons/script.kodi.settings/resources/auth.py)')			
	elif dialog==2:	
		xbmc.executebuiltin('RunPlugin(plugin://plugin.video.seren/?action=authTrakt)')
		#xbmcgui.Dialog().ok('TRAKT', 'Scroll to Accounts Tab. Scroll to Authorise Trakt. Click Authorize... Enter the CODE on your device.')
	elif dialog==3:	
		xbmc.executebuiltin('RunPlugin(plugin://plugin.video.umbrella/?action=traktAuth)')
		#xbmc.executebuiltin('Addon.OpenSettings(plugin.video.umbrella)')
		#xbmcgui.Dialog().ok('TRAKT', 'Scroll to Trakt Tab. Click Authorize Enter the CODE on your device.')
	elif dialog==4:	
		#xbmc.executebuiltin('Addon.OpenSettings(plugin.video.shadow)')
		#xbmcgui.Dialog().ok('TRAKT', 'Scroll to Trakt Tab.... Click ***Sync track to DB***... Select Yes to "Override local DB (Shadow)".. Clcik Yes to "Authenticate Trakt"...Enter the CODE on your device....Click Back button on remote to clear Trakt listing screen.')
		xbmc.executebuiltin('RunPlugin(plugin://plugin.video.shadow?mode=157&url=False)')
		time.sleep(3)
		xbmc.executebuiltin('Action(Left)')
		time.sleep(1)
		xbmc.executebuiltin('Action(Select)')
	elif dialog==5:	
		#xbmc.executebuiltin('Addon.OpenSettings(plugin.video.magicdragon)')
		#xbmcgui.Dialog().ok('TRAKT', 'Scroll to Trakt Tab... Click ***Sync track to DB***... Select Yes to "Override local DB (4K)".. Clcik Yes to "Authenticate Trakt"...Enter the CODE on your device....Click Back button on remote to clear Trakt listing screen.')
		xbmc.executebuiltin('RunPlugin(plugin://plugin.video.magicdragon?mode=157&url=False)')
		time.sleep(3)
		xbmc.executebuiltin('Action(Left)')
		time.sleep(1)
		xbmc.executebuiltin('Action(Select)')


elif dialog==5:
	dialog = xbmcgui.Dialog().select('BOTH TABS NEED AUTHORISING', ['Authorise Real Debrid','Authorise Premiumize','Re-Sync all and Reboot'])
	if dialog==0:
		xbmc.executebuiltin('RunScript(script.module.myaccounts, action=realdebridAuth)')
		#xbmcgui.Dialog().ok('AUTH TRAKT AND RD IN HERE', 'Scroll to Trakt click Authorization... After, Scroll to Debrid Accounts Tab. Scroll to REAL-DEBRID and click Authorize. Enter the code on your device.')
	elif dialog==1:
		xbmc.executebuiltin('RunScript(script.module.myaccounts, action=premiumizeAuth)')
	elif dialog==2:
		xbmc.executebuiltin('RunScript(special://home/addons/script.kodi.settings/resources/auth.py)')	