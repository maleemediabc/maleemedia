# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui
import time
import xbmc
import os

xbmc.log(repr(sys.argv))


def main():
	umbrella()
		

	################## COPY TO MY ACCOUNTS ###############################
def umbrella():
	try:     

		authorize = xbmcaddon.Addon("script.module.myaccounts") #from
		umbrella = xbmcaddon.Addon("plugin.video.umbrella") #to

		pmtoken = authorize.getSetting("premiumize.token") #from setting
		umbrella.setSetting("premiumizetoken", pmtoken) #to setting

		pmuser = authorize.getSetting("premiumize.username") #from setting
		umbrella.setSetting("premiumizeusername", pmuser) #to setting

		token = authorize.getSetting("realdebrid.token") #from setting
		umbrella.setSetting("realdebridtoken", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		umbrella.setSetting("realdebrid.clientid", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		umbrella.setSetting("realdebridrefresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		umbrella.setSetting("realdebridsecret", secret) #to setting

		user = authorize.getSetting("realdebrid.username") #from setting
		umbrella.setSetting("realdebridusername", user) #to setting
		
		resolve()
	except:
		resolve()
	################## COPY TO RESOLVEURL ###############################
def resolve():
	try:
		authorize = xbmcaddon.Addon("script.module.myaccounts") #from
		resolveurl = xbmcaddon.Addon("script.module.resolveurl") #to

		token = authorize.getSetting("realdebrid.token") #from setting
		resolveurl.setSetting("RealDebridResolver_token", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		resolveurl.setSetting("RealDebridResolver_client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		resolveurl.setSetting("RealDebridResolver_refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		resolveurl.setSetting("RealDebridResolver_client_secret", secret) #to setting
		
		true = ("true")
		resolveurl.setSetting("RealDebridResolver_enabled", true) #to setting
		
		seren()		
	except:
		seren()
	################## COPY TO SEREN ###############################
def seren():
	try:
		authorize = xbmcaddon.Addon("script.module.myaccounts") #from
		seren = xbmcaddon.Addon("plugin.video.seren") #to

		pmuser = authorize.getSetting("premiumize.username") #from setting
		seren.setSetting("premiumize.username", pmuser) #to setting

		pmtoken = authorize.getSetting("premiumize.token") #from setting
		seren.setSetting("premiumize.token", pmtoken) #to setting

		user = authorize.getSetting("realdebrid.username") #from setting
		seren.setSetting("rd.username", user) #to setting

		token = authorize.getSetting("realdebrid.token") #from setting
		seren.setSetting("rd.auth", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		seren.setSetting("rd.client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		seren.setSetting("rd.refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		seren.setSetting("rd.secret", secret) #to setting

		true = ("true")
		seren.setSetting("realdebrid.enabled", true) #to setting
		
		true = ("true")
		seren.setSetting("premiumize.enabled", true) #to setting
		
		reboot()
	except:
		reboot()
	############################ RESYNC EZRA AND REBOOT ###################################################


def reboot():
		time.sleep(1)
		xbmc.executebuiltin("ActivateWindow(10025,plugin://script.module.ezscrapers/?action=syncMyAccount)")
		time.sleep(5)
		dialog = xbmcgui.Dialog()
		dialog.notification('SYNC', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(5)
		xbmc.executebuiltin('Reboot')
	
	
if __name__ == "__main__":
	main()

