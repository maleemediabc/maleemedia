# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import time
import xbmc, sys
import requests


def MYIP(url='https://api.ipify.org/'):
	ip = requests.get(url).content
	dialog = xbmcgui.Dialog()
	dialog.notification('[COLOR lime][B]NEXUS CoreELEC[/B][/COLOR]', 'Welcome to Kodi', xbmcgui.NOTIFICATION_INFO, 5000)
	#time.sleep(10)	



try:	
	MYIP()
except:
	dialog=xbmcgui.Dialog()
	dialog.ok('******NOT CONNECTED TO INTERNET*******',"[B][COLOR lime]NO INTERNET DETECTED PLEASE CHECK YOUR ETHERNET OR WIFI CONNECTION. IF SETIINGS ARE OKAY CHECK YOUR ROUTER AND CONNECTIONS, THEN TRY REBOOTING. FINALLY CONTACT YOUR INTERNET SERVICE PROVIDER[/COLOR][/B]")
	xbmcgui.Dialog().ok('CoreELEC SETTINGS', 'Scroll to Connections and check your WiFi or Ethernet connection. Addon will open once you click OK')
	xbmc.executebuiltin('RunAddon(service.coreelec.settings)')