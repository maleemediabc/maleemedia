# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui
import time
################################# THIS RUNS EVERY TIME AT STARTUP ################################
################################# ADD LINE FOR EACH ADDON TO INSTALL ################################
xbmc.executebuiltin('InstallAddon(script.module.cocoscrapers)')
xbmc.executebuiltin('InstallAddon(plugin.video.umbrella)')

time.sleep(5)
xbmc.executebuiltin('RunScript(special://home/addons/script.kodi.settings/resources/repoaddonauth.py)')	