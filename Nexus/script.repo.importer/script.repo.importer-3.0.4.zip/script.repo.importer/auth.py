import xbmc, xbmcaddon, xbmcgui, xbmcplugin,os,base64,sys,xbmcvfs
import time

xbmc.executebuiltin('RunScript(special://home/addons/script.repo.importer/installaddons.py)')
time.sleep(120)
xbmc.executebuiltin('RunScript(special://home/addons/script.kodi.settings/resources/repoaddonauth.py)')