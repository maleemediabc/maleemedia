Put the repo or addon in the stuff folder
Put the userdata in the stuff folder

Read the enableaddons.py file for info on enabling the repo or script
Read the installaddons.py file for info on installing addons from original repos