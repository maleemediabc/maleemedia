# -*- coding: utf-8 -*-
from sys import argv

from resources.routing import routing
routing(argv[2],argv[1])