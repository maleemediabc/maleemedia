# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui
import time
import xbmc

xbmc.log(repr(sys.argv))

################## COPY FROM SCRIPT.TRAKT TO MOVIEDB.HELPER ###############################
# script_trakt = xbmcaddon.Addon("script.trakt") #from
# moviedb_helper = xbmcaddon.Addon("plugin.video.moviedb.helper") #to

# auth = script_trakt.getSetting("authorization") #from setting
# moviedb_helper.setSetting("trakt_token", auth) #to setting

# user= script_trakt.getSetting("user")
# slug= '%s | %s' %(user,user)
# moviedb_helper.setSetting("monitor_userslug", slug)


################## COPY TO RESOLVEURL ###############################
myaccounts = xbmcaddon.Addon("script.module.myaccounts") #from
resolveurl = xbmcaddon.Addon("script.module.resolveurl") #to

token = myaccounts.getSetting("realdebrid.token") #from setting
resolveurl.setSetting("RealDebridResolver_token", token) #to setting

client_id = myaccounts.getSetting("realdebrid.client_id") #from setting
resolveurl.setSetting("RealDebridResolver_client_id", client_id) #to setting

refresh = myaccounts.getSetting("realdebrid.refresh") #from setting
resolveurl.setSetting("RealDebridResolver_refresh", refresh) #to setting

secret = myaccounts.getSetting("realdebrid.secret") #from setting
resolveurl.setSetting("RealDebridResolver_client_secret", secret) #to setting

################## COPY TO SEREN ###############################
myaccounts = xbmcaddon.Addon("script.module.myaccounts") #from
seren = xbmcaddon.Addon("plugin.video.seren") #to

user = myaccounts.getSetting("realdebrid.username") #from setting
seren.setSetting("rd.username", user) #to setting

token = myaccounts.getSetting("realdebrid.token") #from setting
seren.setSetting("rd.auth", token) #to setting

client_id = myaccounts.getSetting("realdebrid.client_id") #from setting
seren.setSetting("rd.client_id", client_id) #to setting

refresh = myaccounts.getSetting("realdebrid.refresh") #from setting
seren.setSetting("rd.refresh", refresh) #to setting

secret = myaccounts.getSetting("realdebrid.secret") #from setting
seren.setSetting("rd.secret", secret) #to setting

true = ("true")
seren.setSetting("realdebrid.enabled", true) #to setting

################## COPY TO FOXY ###############################
# myaccounts = xbmcaddon.Addon("script.module.myaccounts") #from
# foxy = xbmcaddon.Addon("plugin.video.foxystreams") #to

# token = myaccounts.getSetting("realdebrid.token") #from setting
# foxy.setSetting("RealDebrid.api_key", token) #to setting

# client_id = myaccounts.getSetting("realdebrid.client_id") #from setting
# foxy.setSetting("RealDebrid.client_id", client_id) #to setting

# refresh = myaccounts.getSetting("realdebrid.refresh") #from setting
# foxy.setSetting("RealDebrid.refresh_token", refresh) #to setting

# secret = myaccounts.getSetting("realdebrid.secret") #from setting
# foxy.setSetting("RealDebrid.client_secret", secret) #to setting

############################ RESYNC FEN AND REBOOT ###################################################
time.sleep(1)
xbmc.executebuiltin("ActivateWindow(10025,plugin://script.module.fenomscrapers/?action=syncMyAccount)")
time.sleep(5)
dialog = xbmcgui.Dialog()
dialog.notification('BOX SETTINGS', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
xbmc.executebuiltin('reboot')