# -*- coding: utf-8 -*-
import xbmc, xbmcaddon, xbmcgui
import time
import xbmc
import os

xbmc.log(repr(sys.argv))


def main():
	resolve()


################## COPY FROM SCRIPT.TRAKT TO MOVIEDB.HELPER ###############################
def trakt():
	try:

		script_trakt = xbmcaddon.Addon("script.trakt") #from
		moviedb_helper = xbmcaddon.Addon("plugin.video.themoviedb.helper") #to

		auth = script_trakt.getSetting("authorization") #from setting
		moviedb_helper.setSetting("trakt_token", auth) #to setting

		user= script_trakt.getSetting("user")
		slug= '%s | %s' %(user,user)
		moviedb_helper.setSetting("monitor_userslug", slug)
		myaccounts()

	except:
		myaccounts()
		

	################## COPY TO MY ACCOUNTS ###############################
def myaccounts():
	try:

		authorize = xbmcaddon.Addon("script.module.myaccounts") #from
		myaccounts = xbmcaddon.Addon("script.module.myaccounts") #to

		token = authorize.getSetting("realdebrid.token") #from setting
		myaccounts.setSetting("realdebrid.token", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		myaccounts.setSetting("realdebrid.client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		myaccounts.setSetting("realdebrid.refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		myaccounts.setSetting("realdebrid.secret", secret) #to setting

		user = authorize.getSetting("realdebrid.username") #from setting
		myaccounts.setSetting("realdebrid.username", user) #to setting
		resolve()
	except:
		resolve()
	################## COPY TO RESOLVEURL ###############################
def resolve():
	try:
		authorize = xbmcaddon.Addon("script.module.myaccounts") #from
		resolveurl = xbmcaddon.Addon("script.module.resolveurl") #to

		token = authorize.getSetting("realdebrid.token") #from setting
		resolveurl.setSetting("RealDebridResolver_token", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		resolveurl.setSetting("RealDebridResolver_client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		resolveurl.setSetting("RealDebridResolver_refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		resolveurl.setSetting("RealDebridResolver_client_secret", secret) #to setting
		
		true = ("true")
		resolveurl.setSetting("RealDebridResolver_enabled", true) #to setting
		
		seren()		
	except:
		seren()
	################## COPY TO SEREN ###############################
def seren():
	try:
		authorize = xbmcaddon.Addon("script.module.myaccounts") #from
		seren = xbmcaddon.Addon("plugin.video.seren") #to

		user = authorize.getSetting("realdebrid.username") #from setting
		seren.setSetting("rd.username", user) #to setting

		token = authorize.getSetting("realdebrid.token") #from setting
		seren.setSetting("rd.auth", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		seren.setSetting("rd.client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		seren.setSetting("rd.refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		seren.setSetting("rd.secret", secret) #to setting

		true = ("true")
		seren.setSetting("realdebrid.enabled", true) #to setting
		foxy()
	except:
		foxy()
	################## COPY TO FOXY ###############################
def foxy():
	try:
		authorize = xbmcaddon.Addon("script.module.myaccounts") #from
		foxy = xbmcaddon.Addon("plugin.video.foxystreams") #to

		token = authorize.getSetting("realdebrid.token") #from setting
		foxy.setSetting("RealDebrid.api_key", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		foxy.setSetting("RealDebrid.client_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		foxy.setSetting("RealDebrid.refresh_token", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		foxy.setSetting("RealDebrid.client_secret", secret) #to setting
		
		true = ("true")
		foxy.setSetting("debrid_enabled.RealDebrid", true) #to setting
		
		realdebrid()
	except:
		realdebrid()
	################## COPY TO REAL DEBRID ###############################
def realdebrid():
	try:
		authorize = xbmcaddon.Addon("script.module.myaccounts") #from
		debrid = xbmcaddon.Addon("script.realdebrid") #to

		token = authorize.getSetting("realdebrid.token") #from setting
		debrid.setSetting("rd_access", token) #to setting

		client_id = authorize.getSetting("realdebrid.client_id") #from setting
		debrid.setSetting("rd_id", client_id) #to setting

		refresh = authorize.getSetting("realdebrid.refresh") #from setting
		debrid.setSetting("rd_refresh", refresh) #to setting

		secret = authorize.getSetting("realdebrid.secret") #from setting
		debrid.setSetting("rd_secret", secret) #to setting
		reboot()
	except:
		reboot()
	############################ RESYNC FEN AND REBOOT ###################################################

def kill():
		os._exit(1)


def reboot():
		time.sleep(1)
		xbmc.executebuiltin("ActivateWindow(10025,plugin://script.module.fenomscrapers/?action=syncMyAccount)")
		time.sleep(5)
		dialog = xbmcgui.Dialog()
		dialog.notification('SYNC', 'Box will now reboot.', xbmcgui.NOTIFICATION_INFO, 10000,sound=True)
		time.sleep(5)
		kill()
	
	
	
if __name__ == "__main__":
	main()

