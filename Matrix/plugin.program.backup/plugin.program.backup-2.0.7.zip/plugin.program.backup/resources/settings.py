import os
	
xbmc.executebuiltin('Addon.OpenSettings(plugin.program.backup)')