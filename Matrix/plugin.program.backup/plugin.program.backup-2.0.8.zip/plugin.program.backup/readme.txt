TO USE THE ADDON ENTER THE ADDON SETTINGS AND NAVIGATE TO WHERE YOU WANT THE FILES TO BE BACKED UP TO.

THE SERVICE SCRIPT WILL RUN EVERY BOOT BACKING UP THE CODED PLUGINS.

TO RESTORE DATA CLICK THE RESTORE ADDON AND IT WILL START THEN REBOOT.

CAN CODE IN WIFI SETTINGS AS WELL.

ADD OR REMOVE PLUGINS FROM THE service.py

plugin.googledrive
plugin.video.4K
plugin.video.fen
plugin.video.seren
plugin.video.shadow
plugin.video.theoath
plugin.video.youtube
screensaver.digitalclock
script.module.myaccounts
script.module.resolveurl
service.coreelec.settings
plugin.program.backup
service.openvfd
weather.multi
pvr.iptvsimple
