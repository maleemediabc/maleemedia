Put the repo or addon in the stuff folder

Read the enableaddons.py file for info on enabling the repo or script